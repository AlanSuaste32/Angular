import { Empleado } from "./empleado.model";

export class EmpleadosService{

    empleados:Empleado[]=[

        new Empleado("Alan", "Suaste", "Presidente", 7800),
        new Empleado("Ana", "Canche", "Directora", 5800),
        new Empleado("Maria", "Fernandez", "Jefa Seccion", 3800),
        new Empleado("Laura", "Lopes", "Administrativo", 2800)
    
      ];

      agregarEmpleadoServicio(empleado:Empleado){

        this.empleados.push(empleado);

      }

}